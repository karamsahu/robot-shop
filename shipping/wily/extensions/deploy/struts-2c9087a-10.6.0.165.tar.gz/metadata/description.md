This bundle monitors the performance of Apache Struts actions.

Look for metrics under the "Struts" node in the Investigator.
