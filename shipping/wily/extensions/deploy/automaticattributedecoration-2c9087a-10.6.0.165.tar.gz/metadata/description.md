Automatic Attribute Decoration is a Java extension that adds ATC attributes from the agent environment. Attributes can taken from environment variables, system information, files, application manifest file and other sources.

## Prerequisites
* CA APM Enterprise Manager 10.7 and later
* CA APM Java agent 10.7 and later
