The Browser Agent lets you monitor web page load performance metrics. It supports the following browser web timings:

* Metric Calculations Using the W3C Navigation Timing API
* Metric Calculations for Dynamic Web Pages
* Metric Calculations for Mobile Devices

The Browser Agent also supports the following features:

* Metric aggregation by browser type
* Integration into APM transaction traces with a breakdown of framework calls to an application
* Installation though the APM Java agent servlet tracer and servlet filter for easy deployment. Using the APM agent installer, you can install the Browser Agent with default monitoring of your environment.

Note: From 10.5 release, the name of the "Browser Response Time" bundle has been renamed to "Browser Agent".