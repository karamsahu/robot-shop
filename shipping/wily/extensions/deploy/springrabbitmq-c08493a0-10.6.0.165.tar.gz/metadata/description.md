# springrabbitmq (10.6.0.165)

## Description
The extension is a monitoring solution to provide extended visibility into Spring - RabbbitMQ used in applications.

## Supported third party versions
SpringBoot 1.3, 1.4, 1.5& also tested with 2.0.0-BUILD-SNAPSHOT
