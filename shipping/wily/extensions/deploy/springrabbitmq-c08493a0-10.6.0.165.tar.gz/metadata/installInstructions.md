# springrabbitmq (10.6.0.165)

# Spring AMQP Rabbit MQ Monitoring
In addition to the core Introscope Agent capability of JMS monitoring, this monitoring extensions adds support for Spring AMQP based message handling for Rabbit MQ.
* Inbound Message Handling
  1. With the help of this extension,Introscope discovers inbound messages as request and transaction starting points.
  2. Introscope visualizes the inbound message and request start point as a Frontends|Messaging Services (onMessage)|Queue|{queue}.
* Outbound Message Handling
  1. Outbound messaging calls (Message Put) are shown at the Backends node in the Investigator.The Rabbit MQ and the detailed queue name for the outbound message.
  2. Metric "Backends|Messaging Services (outgoing)|Queue|{queue}".

