# spring (10.6.0.165)

## Description
A solution to monitor Spring Framework, field pack covers spring components like WEBMVC, PORTLET, ASPECTS, CORE CONTAINER, WebServices etc.

## Supported third party versions
Spring Framework 3.x, 4.x

