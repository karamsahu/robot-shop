# springmongo (10.6.0.165)

# Spring Mongo DB Monitoring
* This is a monitoring solution for Spring MongoDB API requests with full support of request details towards the Mongo DB instance.
* Introscope shows the calls to the MongoDB at the Backend node starting with "Mongo DB on {host} at {port}". 
* Further details are discovered request type, the related object to the request and if available, the request criteria.
