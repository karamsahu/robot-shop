This is a AWS backend prototype extension.
