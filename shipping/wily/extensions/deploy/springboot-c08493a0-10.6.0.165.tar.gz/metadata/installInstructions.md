# springboot (10.6.0.165)

# Spring Boot Monitoring
The extension is a monitoring solution to provide extended visibility into Spring - Boot applications.

# Spring Boot Application Discovery
* The monitoring solution discovers requests to the Spring Boot Application by creating a Frontend metric in the Investigator using the classname of the Spring Boot Application definition.
* The correct Frontend name is used in the metric visualization as well as Transaction Traces and Team Center.
